# Jobs Automation skill

A bring-your-own-details job-search skill. No personal information is included.

Install: download `jobs-automation.zip`, unzip it, and add the `jobs-automation` folder as a skill in your AI tool (for Claude, Settings > Skills > Upload). Create your own `profile.json` from `profile.template.json` and keep it private.

Use your own AI and tokens: the prompts in `prompts/ai_prompts.md` work in any AI.

Disclaimer: suggestions are general guidance from information published on websites. They are not legal, migration or professional advice. You make your own decisions.


## Copyright and licence

Copyright (c) 2026 Madhumitha Challa. All rights reserved. Limited personal-use licence: see LICENSE and NOTICE. No redistribution or resale without written permission. Not legal, migration or career advice.
