/**
 * Jobs Automation: keeps your inbox quiet.
 * Runs in YOUR OWN Gmail (Google Apps Script). Nothing leaves your account.
 *
 * What it does, once an hour:
 *  1. Labels the automation's emails "JOBS" and takes them out of the inbox
 *     (they stay searchable; open label JOBS to read them).
 *  2. Moves old report emails to the bin after BIN_AFTER_DAYS (Gmail keeps the bin 30 days).
 * It never touches employer, recruiter or any other email.
 *
 * Setup (about 3 minutes): script.google.com > New project > paste this file >
 * set SENDER below > Run "tidy" once and approve > Triggers (clock icon) >
 * Add trigger > function tidy, time-driven, every hour.
 */
var SENDER = "YOUR_AUTOMATION_SENDER@example.com"; // the address the automation emails come from
var SUBJECTS = ["PREVIEW", "APPLY KIT", "URGENT", "ACTION NEEDED", "Run report", "Night run"];
var BIN_AFTER_DAYS = 14;

function tidy() {
  var label = GmailApp.getUserLabelByName("JOBS") || GmailApp.createLabel("JOBS");
  var subj = SUBJECTS.map(function (s) { return 'subject:"' + s + '"'; }).join(" OR ");
  var q = "from:" + SENDER + " (" + subj + ") in:inbox";
  var threads = GmailApp.search(q, 0, 100);
  threads.forEach(function (t) { t.addLabel(label); t.moveToArchive(); });

  var old = GmailApp.search("label:JOBS from:" + SENDER + " older_than:" + BIN_AFTER_DAYS + "d -is:starred", 0, 100);
  old.forEach(function (t) { t.moveToTrash(); });
}
