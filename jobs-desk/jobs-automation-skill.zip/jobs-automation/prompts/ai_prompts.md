# Prompts for your own AI (you use your own tokens)

Copy a prompt, paste it into the AI you already use (Claude, ChatGPT, Gemini, Copilot, Perplexity or any other), then paste your text where it says. The dashboard's Assistant tab builds these for you with one click.

Safety: remove anything you do not want to share (phone, address, ID numbers) before pasting. Never paste passwords. AI can be wrong: check every claim against the employer's own page and official sources. This is general guidance, not legal, migration or professional advice.

## 1. ATS and quality review
You are a careful resume reviewer. Review the resume below for readability by applicant tracking systems and for clarity. Do not invent facts or numbers. Give: (1) a score out of 100 with a one-line reason, (2) the five most important fixes, each with a before and after example using only facts already in the resume, (3) formatting risks (tables, columns, images, headers), (4) anything that looks inconsistent (dates, titles). Australian spelling. Resume:
[PASTE RESUME]

## 2. Job description skills match
Compare the resume to the job description. List: skills and requirements the resume clearly shows (quote the line), required skills that are missing, and nice-to-have skills that are missing. Give a match score out of 100. Do not suggest claiming skills I do not have; for each missing skill suggest an honest way to build it (course, project). Resume:
[PASTE RESUME]
Job description:
[PASTE JOB DESCRIPTION]

## 3. Organisation values match
Here are an organisation's stated values and my resume. For each value, say whether my resume shows real evidence (quote it), thin evidence, or none, and suggest one honest example I could add only if it is true. Give an overall score out of 100. Values (copied from the organisation's website, link: [PASTE LINK]):
[PASTE VALUES]
Resume:
[PASTE RESUME]

## 4. Am I eligible, and what should I apply for?
I am a [first/second/final]-year student in [course], expected to finish [month year]. My work rights are [citizen / permanent resident / student visa / other]. Using only information published on employer, university and government websites (cite each source with a link), explain which of these suit me now: graduate programs, vacation or summer programs, internships, cadetships, part-time or casual roles, entry-level roles. Say what is usually required (year of study, working rights, citizenship) and note where employers differ. If something depends on my visa or legal status, say I should check the official source or a registered professional. Keep the tone professional.

## 5. Tailored cover letter draft
Write a one-page cover letter for this job using only the facts in my resume. Do not add numbers or experience that are not there. Mirror the job description's language where it is true. Resume: [PASTE RESUME]. Job: [PASTE JOB DESCRIPTION].

## 6. Research this employer
Research [EMPLOYER] for a job application: what they do, recent news, stated values, how they run graduate and student programs, and typical interview format. Cite sources with links and say when something could not be confirmed.
